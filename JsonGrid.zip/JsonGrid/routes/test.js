var express = require('express');
var router = express.Router();

var assert = require('assert');
var path = require('path');
var fs = require("fs");


/* GET home page. */


router.get('/', function(req, res, next) {
	res.sendFile(path.join(__dirname + '/datatable.html'));
});

router.post('/', function(req, res, next) {

});


module.exports = router;